"""
THE TWO EXITS — faithful projections of the substrate (HACI-C v2: total).

Faithful = from_X(to_X(S)) recovers S exactly, graph AND body, for every role.

v1 carried single-line content inline:  ! text⟦id|from|authority|role|refs⟧
v2 adds a block form for MULTI-LINE / CODE bodies, so the bridge is now total
over all five bridgeable roles (COMMAND, PROPOSAL, QUESTION, EVIDENCE, CODE):

    «id|from|authority|role|refs|N»        <- block header, N = content line count
    <line 1 of content>                    <- N verbatim lines follow; count makes
    <line 2 of content>                       parsing unambiguous no matter what the
    ...                                        body contains («», ⟦⟧, |, blank lines)

The two delimiters are disjoint (« » block vs ⟦ ⟧ inline) so single- and multi-
line messages never collide. Role lives in the header, never sniffed from casing,
so the round-trip is exact. The ! ? > sugar on the first line is decorative.

The honest cost is unchanged: provenance rides visibly with the human text.
"""
from typing import List
from .substrate import Msg
from .canonical import canon

SUGAR = {"COMMAND": "! ", "QUESTION": "? ", "EVIDENCE": "> "}   # decorative only
OPEN, CLOSE, SEP = "⟦", "⟧", "|"      # inline tail (single-line)
BOPEN, BCLOSE = "«", "»"               # block header (multi-line / CODE)


# ---- Machine exit (canonical MACI, JSON Lines) --------------------------
def to_M(S: List[Msg]) -> str:
    out = []
    for m in S:
        obj = {"maci": "0.1.0", "id": m.id, "from": m.frm, "role": m.role,
               "authority": m.authority, "content": m.content, "refs": list(m.refs)}
        out.append(canon(obj).decode("utf-8").rstrip("\n"))
    return "\n".join(out)


def from_M(text: str) -> List[Msg]:
    import json
    out = []
    for line in text.split("\n"):
        if not line.strip():
            continue
        o = json.loads(line)
        out.append(Msg(id=o["id"], frm=o["from"], role=o["role"],
                       authority=o["authority"], content=o["content"],
                       refs=list(o.get("refs", []))))
    return out


# ---- Human exit (HACI-C v2) ---------------------------------------------
def to_H(S: List[Msg], carry: bool = True) -> str:
    """carry=False re-opens the eskimo seam (drops refs) — used by the mutation test."""
    out = []
    for m in S:
        sugar = SUGAR.get(m.role, "")
        refs_s = ",".join(m.refs) if (carry and m.refs) else ""
        if "\n" in m.content:                       # block form
            lines = m.content.split("\n")
            header = BOPEN + SEP.join([m.id, m.frm, m.authority, m.role, refs_s, str(len(lines))]) + BCLOSE
            lines[0] = sugar + lines[0]
            out.append(header + "\n" + "\n".join(lines))
        else:                                       # inline form
            fields = [m.id, m.frm, m.authority, m.role] + ([refs_s] if refs_s else [])
            out.append(sugar + m.content + OPEN + SEP.join(fields) + CLOSE)
    return "\n".join(out)


def from_H(text: str) -> List[Msg]:
    lines = text.split("\n")
    out, i = [], 0
    while i < len(lines):
        line = lines[i]
        if line.startswith(BOPEN) and line.endswith(BCLOSE):        # block header
            f = line[1:-1].split(SEP)
            mid, frm, authority, role, refs_s, n = f[0], f[1], f[2], f[3], f[4], int(f[5])
            body = lines[i + 1:i + 1 + n]
            sugar = SUGAR.get(role, "")
            if body and body[0].startswith(sugar):
                body[0] = body[0][len(sugar):]
            refs = refs_s.split(",") if refs_s else []
            out.append(Msg(id=mid, frm=frm, role=role, authority=authority,
                           content="\n".join(body), refs=refs))
            i += 1 + n
            continue
        if not line.strip():
            i += 1
            continue
        if not line.endswith(CLOSE) or OPEN not in line:            # inline tail
            raise ValueError(f"HACI-C line missing provenance tail: {line!r}")
        left, tail = line[:line.rindex(OPEN)], line[line.rindex(OPEN) + 1:-1]
        p = tail.split(SEP)
        mid, frm, authority, role = p[0], p[1], p[2], p[3]
        refs = p[4].split(",") if len(p) > 4 and p[4] else []
        sugar = SUGAR.get(role, "")
        content = left[len(sugar):] if left.startswith(sugar) else left
        out.append(Msg(id=mid, frm=frm, role=role, authority=authority,
                       content=content, refs=refs))
        i += 1
    return out
