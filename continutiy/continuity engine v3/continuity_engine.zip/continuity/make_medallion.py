#!/usr/bin/env python3
"""continuity-medallion.png — the sigil: one substrate (S), two faithful exits
(H human/purple, M machine/cyan) bridged in continuity-teal. Supersampled."""
import math
from PIL import Image, ImageDraw, ImageFont

SS = 4
W = 512 * SS
SEA   = (7, 14, 22, 255)
LINE  = (150, 180, 210)
TEAL  = (95, 208, 192)
HUMAN = (176, 112, 200)
MACH  = (70, 199, 216)
GOLD  = (217, 164, 65)

img = Image.new("RGBA", (W, W), (0, 0, 0, 0))
d = ImageDraw.Draw(img)
cx = cy = W // 2

def circle(c, r, **kw): d.ellipse([c[0]-r, c[1]-r, c[0]+r, c[1]+r], **kw)

# disc + subtle inner fill + teal rim
circle((cx, cy), W*0.48, fill=SEA)
circle((cx, cy), W*0.48, outline=TEAL, width=3*SS)
circle((cx, cy), W*0.44, outline=(*LINE, 60), width=1*SS)

# the two exits, upper-left (H) and upper-right (M)
ang_h, ang_m = math.radians(207), math.radians(-27)
R = W*0.30
hx, hy = cx + R*math.cos(ang_h), cy + R*math.sin(ang_h)
mx, my = cx + R*math.cos(ang_m), cy + R*math.sin(ang_m)
# bridge lines from each exit to the substrate
for (ex, ey, col) in [(hx, hy, HUMAN), (mx, my, MACH)]:
    d.line([ex, ey, cx, cy], fill=(*col, 150), width=2*SS)
# exit nodes
circle((hx, hy), W*0.075, fill=SEA, outline=HUMAN, width=3*SS)
circle((mx, my), W*0.075, fill=SEA, outline=MACH, width=3*SS)

# central substrate ring (the validated pivot)
circle((cx, cy), W*0.16, fill=SEA, outline=TEAL, width=4*SS)
circle((cx, cy), W*0.205, outline=(*TEAL, 90), width=1*SS)

def font(path, size):
    try: return ImageFont.truetype(path, size)
    except Exception: return ImageFont.load_default()

serif = "/usr/share/fonts/truetype/dejavu/DejaVuSerif-Bold.ttf"
mono  = "/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf"

def centered(text, fnt, c, fill):
    b = d.textbbox((0, 0), text, font=fnt)
    d.text((c[0]-(b[2]-b[0])/2 - b[0], c[1]-(b[3]-b[1])/2 - b[1]), text, font=fnt, fill=fill)

centered("S", font(serif, int(W*0.20)), (cx, cy), TEAL)         # the substrate
centered("H", font(serif, int(W*0.07)), (hx, hy), HUMAN)
centered("M", font(serif, int(W*0.07)), (mx, my), MACH)
centered("CONTINUITY", font(mono, int(W*0.052)), (cx, cy + int(W*0.31)), (*LINE, 235))
centered("· CTY ·", font(mono, int(W*0.042)), (cx, cy + int(W*0.375)), (*TEAL, 235))

img.resize((512, 512), Image.LANCZOS).save("continuity-medallion.png")
print("wrote continuity-medallion.png")
