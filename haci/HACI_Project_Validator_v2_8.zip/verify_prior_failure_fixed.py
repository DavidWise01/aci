#!/usr/bin/env python3
from pathlib import Path
import tempfile
from haci_project_validator_v2_8 import validate_project

def write(root, rel, text):
    p = Path(root) / rel
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(text, encoding="utf-8")

with tempfile.TemporaryDirectory() as tmp:
    root = Path(tmp)
    write(root, "10_memory/m.haci", """? m alpha problem
? m beta problem
m alpha clarify ?
m beta answer >
m alpha answer >
""")
    r = validate_project(root, strict=True)
    assert r.ok, r.errors
    convs = [c for c in r.conversations if c["kind"] == "conversation" and c["start"]["outbound"] == "ask"]
    alpha = [c for c in convs if "alpha problem" in c["start"]["payload"]][0]
    assert any(ret["inbound"] == "ask" and "alpha clarify" in ret["payload"] for ret in alpha["returns"]), alpha
print("PASS: prior v2.7 return-question failure now pairs uniquely")
