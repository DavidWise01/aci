# HACI Project Validator v2.8

Return-Question Pairing Patch over v2.7.

Run:

```bash
python test_haci_project_validator_v2_8.py
python haci_project_validator_v2_8.py examples/clean_return_question --strict
python haci_project_validator_v2_8.py examples/failure_ambiguous_question --strict
```
